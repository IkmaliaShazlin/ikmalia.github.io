// Filter language
const movies = [
  { title: "The Greatest Showman", language: "English" },
  { title: "Kanchana", language: "Tamil" },
  { title: "Pusaka", language: "Indonesian" },
  { title: "Sayu Yang Syukur", language: "Malay" },
  { title: "Us and Them", language: "Chinese" }
];